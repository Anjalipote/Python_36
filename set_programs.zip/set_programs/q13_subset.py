"""
Question 13:
Determine whether the first set is a subset of the second set.
"""

a = {1, 2}
b = {1, 2, 3, 4}
print("First set is a subset of the second set:", a.issubset(b))
