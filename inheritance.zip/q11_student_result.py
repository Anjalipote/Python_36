class Student:
    def __init__(self, roll_no, name, course):
        self.roll_no = roll_no
        self.name = name
        self.course = course

    def display(self):
        print(f"Roll No : {self.roll_no}")
        print(f"Name    : {self.name}")
        print(f"Course  : {self.course}")


class Result(Student):
    def __init__(self, roll_no, name, course, m1, m2, m3):
        super().__init__(roll_no, name, course)
        self.marks = [m1, m2, m3]  # each out of 100

    def total(self):
        return sum(self.marks)

    def percentage(self):
        return self.total() / 3

    def grade(self):
        p = self.percentage()
        if p >= 90:
            return "A+"
        elif p >= 80:
            return "A"
        elif p >= 70:
            return "B"
        elif p >= 60:
            return "C"
        elif p >= 40:
            return "D"
        return "F"

    def display(self):
        super().display()
        print(f"Marks   : {self.marks}")
        print(f"Total   : {self.total()} / 300")
        print(f"Percent : {self.percentage():.2f}%")
        print(f"Grade   : {self.grade()}")


r = Result(1, "Aarav", "B.Tech", 85, 78, 92)
r.display()
