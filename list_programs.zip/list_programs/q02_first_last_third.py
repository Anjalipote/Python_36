"""
Question 2:
Create a list of five integers. Display: first element, last element, third element.
"""

numbers = [10, 20, 30, 40, 50]
print("First element :", numbers[0])
print("Last element  :", numbers[-1])
print("Third element :", numbers[2])
