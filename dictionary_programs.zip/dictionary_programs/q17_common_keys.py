"""
Question 17:
Given two dictionaries, find the keys that are common to both dictionaries.
"""

d1 = {"a": 1, "b": 2, "c": 3}
d2 = {"b": 20, "c": 30, "d": 40}
print("Common keys:", set(d1) & set(d2))
