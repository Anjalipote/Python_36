sentence = input("Enter a sentence: ")

words = sentence.split()
reversed_words = []
for w in words:
    reversed_words.insert(0, w)   # put each word at the front

print("Reversed sentence:", " ".join(reversed_words))
