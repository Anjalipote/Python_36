"""
Question 30:
Create a tuple of patient records (Patient ID, Name, Age, Blood Group). Display all records, search by ID, count total patients, display patients with a specific blood group.
"""

patients = (
    (1, "Ravi", 45, "O+"),
    (2, "Sneha", 32, "A+"),
    (3, "Kiran", 60, "O+"),
    (4, "Meera", 28, "B+"),
)

print("All records:")
for p in patients:
    print(p)

pid = int(input("\nEnter patient ID to search: "))
for p in patients:
    if p[0] == pid:
        print("Found:", p)
        break
else:
    print("Patient not found.")

print("Total patients:", len(patients))

group = input("\nEnter blood group: ").strip().upper()
matches = [p for p in patients if p[3] == group]
if matches:
    print("Patients with blood group", group + ":")
    for p in matches:
        print(p)
else:
    print("No patients with that blood group.")
