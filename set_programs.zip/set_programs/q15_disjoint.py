"""
Question 15:
Determine whether two sets have no elements in common.
"""

a = {1, 2, 3}
b = {4, 5, 6}
if a.isdisjoint(b):
    print("The sets have no elements in common.")
else:
    print("The sets have common elements:", a & b)
