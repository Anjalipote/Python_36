"""
Question 24:
Store temperatures of seven days in a tuple and determine: maximum, minimum, average.
"""

temps = (31, 33, 35, 34, 30, 29, 32)
print("Maximum temperature:", max(temps))
print("Minimum temperature:", min(temps))
print("Average temperature:", round(sum(temps) / len(temps), 2))
