"""
Question 22:
Find common elements between two lists.
"""

list1 = input("Enter elements of the first list (space separated): ").split()
list2 = input("Enter elements of the second list (space separated): ").split()
common = []
for x in list1:
    if x in list2 and x not in common:
        common.append(x)
print("Common elements:", common)
