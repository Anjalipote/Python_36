"""
Question 5:
Create a dictionary of cities and their populations. Remove a specified city from the dictionary.
"""

cities = {"Mumbai": 20_400_000, "Delhi": 16_800_000, "Pune": 7_400_000, "Chennai": 11_000_000}
city = input("Enter city to remove: ").strip()
if city in cities:
    del cities[city]
    print("Updated dictionary:", cities)
else:
    print("City not found.")
