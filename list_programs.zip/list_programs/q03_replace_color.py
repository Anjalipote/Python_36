"""
Question 3:
Create a list of colors. Replace the third color with another color and display the updated list.
"""

colors = ["red", "green", "blue", "yellow", "white"]
print("Original list:", colors)
colors[2] = "pink"
print("Updated list :", colors)
