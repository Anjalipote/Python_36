sentence = input("Enter a sentence: ")

words = sentence.split()
if not words:
    print("No words entered.")
else:
    shortest = words[0]
    for w in words:
        if len(w) < len(shortest):
            shortest = w
    print(f"Shortest word: {shortest} ({len(shortest)} letters)")
