"""
Question 4:
Create a list of numbers. Add one element at the end, one at the beginning and one at a specified position. Display the updated list.
"""

numbers = [10, 20, 30, 40, 50]
numbers.append(60)        # at the end
numbers.insert(0, 5)      # at the beginning
numbers.insert(3, 25)     # at position (index) 3
print("Updated list:", numbers)
