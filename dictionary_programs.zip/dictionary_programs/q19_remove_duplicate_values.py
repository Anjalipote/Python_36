"""
Question 19:
Create a dictionary containing duplicate values and remove duplicate values while retaining the corresponding keys where appropriate.
"""

data = {"a": 1, "b": 2, "c": 1, "d": 3, "e": 2}
seen = set()
result = {}
for key, value in data.items():
    if value not in seen:       # keep only the first key for each value
        seen.add(value)
        result[key] = value
print("Original:", data)
print("Without duplicate values:", result)
