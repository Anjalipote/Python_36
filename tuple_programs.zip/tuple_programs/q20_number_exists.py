"""
Question 20:
Accept a number from the user and determine whether it exists in the tuple.
"""

t = (4, 8, 15, 16, 23, 42)
n = int(input("Enter a number: "))
print(n, "exists in the tuple." if n in t else "does not exist in the tuple.")
