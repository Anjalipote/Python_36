class Animal:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def eat(self):
        print(f"{self.name} is eating.")

    def sleep(self):
        print(f"{self.name} is sleeping.")

    def sound(self):
        print(f"{self.name} makes a sound.")

    def display(self):
        print(f"{self.__class__.__name__}: {self.name}, age {self.age}")


class Dog(Animal):
    def sound(self):
        print(f"{self.name} says: Woof! Woof!")

    def behavior(self):
        print(f"{self.name} fetches the ball and guards the house.")


class Cat(Animal):
    def sound(self):
        print(f"{self.name} says: Meow!")

    def behavior(self):
        print(f"{self.name} climbs trees and chases mice.")


class Cow(Animal):
    def sound(self):
        print(f"{self.name} says: Moo!")

    def behavior(self):
        print(f"{self.name} grazes in the field and gives milk.")


for animal in (Dog("Tommy", 3), Cat("Kitty", 2), Cow("Gauri", 5)):
    animal.display()
    animal.eat()
    animal.sound()
    animal.behavior()
    print()
