"""
Question 24:
Rotate a list left by one position and right by one position.
"""

numbers = [1, 2, 3, 4, 5]
left = numbers[1:] + numbers[:1]
right = numbers[-1:] + numbers[:-1]
print("Original      :", numbers)
print("Rotated left  :", left)
print("Rotated right :", right)
