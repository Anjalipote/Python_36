"""
Question 24:
Create sets representing products belonging to different categories. Find products that belong to both categories.
"""

electronics = {"Phone", "Laptop", "Headphones", "Smart Watch"}
accessories = {"Headphones", "Smart Watch", "Phone Case", "Charger"}
print("Products in both categories:", electronics & accessories)
