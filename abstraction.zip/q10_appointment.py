from abc import ABC, abstractmethod


class Appointment(ABC):
    def __init__(self, patient_name, doctor):
        self.patient_name = patient_name
        self.doctor = doctor

    @abstractmethod
    def book_appointment(self):
        pass

    @abstractmethod
    def calculate_fee(self):
        pass


class GeneralAppointment(Appointment):
    def book_appointment(self):
        print(f"General: {self.patient_name} booked with Dr. {self.doctor} "
              f"(next available slot, 1-2 days).")

    def calculate_fee(self):
        return 500


class SpecialistAppointment(Appointment):
    def __init__(self, patient_name, doctor, speciality):
        super().__init__(patient_name, doctor)
        self.speciality = speciality

    def book_appointment(self):
        print(f"Specialist: {self.patient_name} booked with Dr. {self.doctor} "
              f"({self.speciality}), advance booking required.")

    def calculate_fee(self):
        return 1500


class EmergencyAppointment(Appointment):
    def book_appointment(self):
        print(f"Emergency: {self.patient_name} seen immediately by Dr. {self.doctor}.")

    def calculate_fee(self):
        return 500 + 2000  # consultation + emergency charge


appointments = [GeneralAppointment("Ravi", "Sharma"),
                SpecialistAppointment("Anita", "Iyer", "Cardiology"),
                EmergencyAppointment("Suresh", "Khan")]

for a in appointments:
    a.book_appointment()
    print(f"   Fee: Rs. {a.calculate_fee():.2f}\n")
