"""
Question 17:
Two students have selected different subjects. Store their subjects in two sets and determine the subjects studied by both.
"""

student1 = {"Maths", "Physics", "Chemistry", "English"}
student2 = {"Physics", "Biology", "English", "History"}
print("Subjects studied by both students:", student1 & student2)
