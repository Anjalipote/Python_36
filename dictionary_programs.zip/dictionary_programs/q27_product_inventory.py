"""
Question 27:
Product names and quantities: add a product, update quantity, delete a product, search for a product, display products with quantity below 10.
"""

stock = {"Pen": 100, "Notebook": 8, "Bag": 5, "Bottle": 40}
while True:
    print("\n--- Inventory ---")
    print("1. Add product\n2. Update quantity\n3. Delete product\n4. Search product")
    print("5. Show products with quantity below 10\n6. Display all\n7. Exit")
    choice = input("Enter your choice: ")
    if choice == "1":
        name = input("Enter product name: ")
        stock[name] = int(input("Enter quantity: "))
        print("Product added.")
    elif choice == "2":
        name = input("Enter product name: ")
        if name in stock:
            stock[name] = int(input("Enter new quantity: "))
            print("Quantity updated.")
        else:
            print("Product not found.")
    elif choice == "3":
        name = input("Enter product name: ")
        if stock.pop(name, None) is not None:
            print("Product deleted.")
        else:
            print("Product not found.")
    elif choice == "4":
        name = input("Enter product name: ")
        print(f"{name}: {stock[name]}" if name in stock else "Product not found.")
    elif choice == "5":
        low = {n: q for n, q in stock.items() if q < 10}
        print("Low stock products:", low if low else "none")
    elif choice == "6":
        print(stock)
    elif choice == "7":
        break
    else:
        print("Invalid choice.")
