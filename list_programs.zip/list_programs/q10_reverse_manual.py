"""
Question 10:
Reverse a list without using the reverse() method.
"""

numbers = [1, 2, 3, 4, 5, 6]
reversed_list = []
for i in range(len(numbers) - 1, -1, -1):
    reversed_list.append(numbers[i])
print("Original:", numbers)
print("Reversed:", reversed_list)
