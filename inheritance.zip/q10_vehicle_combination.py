class Vehicle:
    def __init__(self, brand, wheels):
        self.brand = brand
        self.wheels = wheels

    def display(self):
        print(f"Brand  : {self.brand}")
        print(f"Wheels : {self.wheels}")


class Car(Vehicle):  # hierarchical: Vehicle -> Car
    def __init__(self, brand, doors):
        super().__init__(brand, 4)
        self.doors = doors

    def display(self):
        super().display()
        print(f"Doors  : {self.doors}")


class Bike(Vehicle):  # hierarchical: Vehicle -> Bike
    def __init__(self, brand, engine_cc):
        super().__init__(brand, 2)
        self.engine_cc = engine_cc

    def display(self):
        super().display()
        print(f"Engine : {self.engine_cc} cc")


class SportsCar(Car):  # multilevel: Vehicle -> Car -> SportsCar
    def __init__(self, brand, doors, top_speed):
        super().__init__(brand, doors)
        self.top_speed = top_speed

    def display(self):
        super().display()
        print(f"Top speed : {self.top_speed} km/h")


class ElectricBike(Bike):  # multilevel: Vehicle -> Bike -> ElectricBike
    def __init__(self, brand, engine_cc, battery_kwh):
        super().__init__(brand, engine_cc)
        self.battery_kwh = battery_kwh

    def display(self):
        super().display()
        print(f"Battery   : {self.battery_kwh} kWh")


print("--- Sports Car ---")
SportsCar("Ferrari", 2, 340).display()
print("\n--- Electric Bike ---")
ElectricBike("Ather", 0, 3.7).display()
print("\n--- Car ---")
Car("Honda", 4).display()
print("\n--- Bike ---")
Bike("Yamaha", 150).display()
