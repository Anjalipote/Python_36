"""
Question 8:
Create a dictionary and display: all keys, all values, all key-value pairs.
"""

data = {"name": "Amit", "age": 20, "course": "BCA"}
print("Keys  :", list(data.keys()))
print("Values:", list(data.values()))
print("Items :", list(data.items()))
