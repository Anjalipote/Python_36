import math

# cos(x) = 1 - x^2/2! + x^4/4! - x^6/6! + ...   (x in radians)
x = float(input("Enter x (in radians): "))
n = int(input("Enter number of terms: "))

term = 1.0
total = 1.0
for i in range(1, n):
    term *= -x * x / ((2 * i - 1) * (2 * i))
    total += term

print(f"cos({x}) by series ({n} terms) = {total:.6f}")
print(f"cos({x}) by math.cos          = {math.cos(x):.6f}")
