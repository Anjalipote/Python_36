s = input("Enter a string: ")

freq = {}
for ch in s:
    if ch != " ":
        freq[ch] = freq.get(ch, 0) + 1

print("Character frequencies (spaces ignored):")
for ch, c in freq.items():
    print(f"  '{ch}' : {c}")
