"""
Question 19:
Store 15 integers in a tuple and count even and odd numbers.
"""

t = (12, 7, 9, 22, 35, 40, 18, 5, 61, 74, 3, 28, 99, 50, 17)
even = sum(1 for n in t if n % 2 == 0)
odd = len(t) - even
print("Even numbers:", even)
print("Odd numbers :", odd)
