"""
Question 17:
Find the largest and smallest number in a tuple without using max() and min().
"""

t = (45, 12, 89, 3, 67, 21, 90, 5)
largest = smallest = t[0]
for n in t:
    if n > largest:
        largest = n
    if n < smallest:
        smallest = n
print("Largest :", largest)
print("Smallest:", smallest)
