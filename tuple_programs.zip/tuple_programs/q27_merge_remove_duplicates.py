"""
Question 27:
Merge two tuples and remove duplicate elements.
"""

t1 = (1, 2, 3, 4)
t2 = (3, 4, 5, 6)
merged = t1 + t2
unique = []
for x in merged:
    if x not in unique:
        unique.append(x)
print("Merged tuple          :", merged)
print("Without duplicates    :", tuple(unique))
