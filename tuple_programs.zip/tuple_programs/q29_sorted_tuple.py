"""
Question 29:
Convert a tuple into a sorted tuple in ascending and descending order.
"""

t = (45, 12, 89, 3, 67)
print("Ascending :", tuple(sorted(t)))
print("Descending:", tuple(sorted(t, reverse=True)))
