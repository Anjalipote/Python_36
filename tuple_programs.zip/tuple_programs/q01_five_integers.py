"""
Question 1:
Create a tuple of five integers and display it.
"""

numbers = (10, 20, 30, 40, 50)
print("Tuple:", numbers)
