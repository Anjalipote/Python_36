"""
Question 15:
Accept a sentence and create a dictionary containing each word and the number of times it occurs.
"""

sentence = input("Enter a sentence: ")
freq = {}
for word in sentence.lower().split():
    freq[word] = freq.get(word, 0) + 1
print(freq)
