class Vehicle:
    def __init__(self, brand, model):
        self.brand = brand
        self.model = model

    def display(self):
        print(f"Brand : {self.brand}")
        print(f"Model : {self.model}")


class Car(Vehicle):
    def __init__(self, brand, model, fuel_type, price):
        super().__init__(brand, model)
        self.fuel_type = fuel_type
        self.price = price

    def discounted_price(self, discount_percent):
        return self.price - (self.price * discount_percent / 100)

    def display(self):
        super().display()
        print(f"Fuel  : {self.fuel_type}")
        print(f"Price : Rs. {self.price:.2f}")


car = Car("Hyundai", "Creta", "Petrol", 1500000)
car.display()

discount = float(input("\nEnter discount percentage: "))
print(f"Discounted price: Rs. {car.discounted_price(discount):.2f}")
