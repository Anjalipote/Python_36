"""
Question 4:
Create a tuple of colors. Check whether a given color exists in the tuple.
"""

colors = ("red", "green", "blue", "yellow")
color = input("Enter a color: ").strip().lower()
if color in colors:
    print(color, "exists in the tuple.")
else:
    print(color, "does not exist in the tuple.")
