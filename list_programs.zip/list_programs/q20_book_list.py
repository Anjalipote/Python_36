"""
Question 20:
Create a list of books. Implement: add a new book, search a book, remove a book, display all books, count total books.
"""

books = ["Python Basics", "Data Structures", "Algorithms"]
while True:
    print("\n--- Library ---")
    print("1. Add book\n2. Search book\n3. Remove book\n4. Display all books\n5. Count books\n6. Exit")
    choice = input("Enter your choice: ")
    if choice == "1":
        books.append(input("Enter book name: "))
        print("Book added.")
    elif choice == "2":
        name = input("Enter book name to search: ")
        print("Book found." if name in books else "Book not found.")
    elif choice == "3":
        name = input("Enter book name to remove: ")
        if name in books:
            books.remove(name)
            print("Book removed.")
        else:
            print("Book not found.")
    elif choice == "4":
        for i, b in enumerate(books, 1):
            print(i, b)
    elif choice == "5":
        print("Total books:", len(books))
    elif choice == "6":
        break
    else:
        print("Invalid choice.")
