"""
Question 16:
Create a nested list storing Student Name, Roll Number and Marks. Display all student details.
"""

students = [
    ["Amit", 101, 85],
    ["Bhavna", 102, 92],
    ["Chetan", 103, 78],
]
print(f"{'Name':<10}{'Roll No':<10}{'Marks':<6}")
for name, roll, marks in students:
    print(f"{name:<10}{roll:<10}{marks:<6}")
