n = int(input("Enter a number: "))

sign = -1 if n < 0 else 1
temp = abs(n)
reverse = 0
while temp > 0:
    reverse = reverse * 10 + temp % 10
    temp //= 10

print(f"Reverse of {n} = {sign * reverse}")
