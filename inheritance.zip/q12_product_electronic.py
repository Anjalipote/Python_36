class Product:
    def __init__(self, product_id, name, price):
        self.product_id = product_id
        self.name = name
        self.price = price

    def display(self):
        print(f"Product ID : {self.product_id}")
        print(f"Name       : {self.name}")
        print(f"Price      : Rs. {self.price:.2f}")


class ElectronicProduct(Product):
    def __init__(self, product_id, name, price, brand, warranty_years):
        super().__init__(product_id, name, price)
        self.brand = brand
        self.warranty_years = warranty_years

    def final_price(self, discount_percent):
        return self.price - (self.price * discount_percent / 100)

    def display(self):
        super().display()
        print(f"Brand      : {self.brand}")
        print(f"Warranty   : {self.warranty_years} year(s)")


tv = ElectronicProduct(1, "Smart TV 43 inch", 32000, "Sony", 2)
tv.display()

discount = float(input("\nEnter discount percentage: "))
print(f"Final price after {discount}% discount: Rs. {tv.final_price(discount):.2f}")
