def compress(s):
    compressed = ""
    i = 0
    while i < len(s):
        count = 1
        while i + count < len(s) and s[i + count] == s[i]:
            count += 1
        compressed += s[i] + str(count)
        i += count
    # Return the original if compression does not make it shorter
    return compressed if len(compressed) < len(s) else s


s = input("Enter a string: ")
print("Result:", compress(s))
