"""
Question 28:
Store scores of a batsman in 10 matches and calculate: highest, lowest, total runs, average, centuries (>=100), half-centuries (50-99).
"""

scores = [102, 45, 67, 12, 130, 55, 0, 89, 101, 34]
print("Highest score :", max(scores))
print("Lowest score  :", min(scores))
print("Total runs    :", sum(scores))
print("Average runs  :", sum(scores) / len(scores))
print("Centuries (>=100)     :", sum(1 for s in scores if s >= 100))
print("Half-centuries (50-99):", sum(1 for s in scores if 50 <= s <= 99))
