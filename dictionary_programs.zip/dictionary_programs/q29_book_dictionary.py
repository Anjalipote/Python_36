"""
Question 29:
Book IDs and book names: add a book, search a book, remove a book, display all books, count total books.
"""

books = {1: "Python Basics", 2: "Data Structures", 3: "Algorithms"}
while True:
    print("\n--- Library ---")
    print("1. Add book\n2. Search book\n3. Remove book\n4. Display all\n5. Count books\n6. Exit")
    choice = input("Enter your choice: ")
    if choice == "1":
        book_id = int(input("Enter book ID: "))
        books[book_id] = input("Enter book name: ")
        print("Book added.")
    elif choice == "2":
        book_id = int(input("Enter book ID: "))
        print(f"{book_id}: {books[book_id]}" if book_id in books else "Book not found.")
    elif choice == "3":
        book_id = int(input("Enter book ID: "))
        if books.pop(book_id, None) is not None:
            print("Book removed.")
        else:
            print("Book not found.")
    elif choice == "4":
        for book_id, name in books.items():
            print(f"{book_id}: {name}")
    elif choice == "5":
        print("Total books:", len(books))
    elif choice == "6":
        break
    else:
        print("Invalid choice.")
