"""
Question 10:
Accept five student names and their marks from the user and store them in a dictionary.
"""

students = {}
for i in range(5):
    name = input(f"Enter name of student {i + 1}: ")
    students[name] = int(input(f"Enter marks of {name}: "))
print("Student records:", students)
