"""
Question 21:
Technical skills of two employees: common skills, unique to Employee 1, unique to Employee 2, all available skills.
"""

emp1 = {"Python", "SQL", "Excel", "Git"}
emp2 = {"Java", "SQL", "Git", "Docker"}
print("Common skills        :", emp1 & emp2)
print("Unique to Employee 1 :", emp1 - emp2)
print("Unique to Employee 2 :", emp2 - emp1)
print("All available skills :", emp1 | emp2)
