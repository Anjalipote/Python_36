import re

email = input("Enter an email address: ").strip()

pattern = r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$"

if re.match(pattern, email) and ".." not in email:
    print(f"'{email}' is a valid email address.")
else:
    print(f"'{email}' is not a valid email address.")
