n = int(input("Enter n: "))

total = 0
i = 1
while i <= n:
    total += i
    i += 2

print(f"Sum of odd numbers up to {n} = {total}")
