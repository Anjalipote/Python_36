"""
Question 22:
Create tuples containing Employee ID, Name, Salary. Display all employee information.
"""

employees = (
    (1, "Ravi", 45000),
    (2, "Sneha", 52000),
    (3, "Kiran", 38000),
)
print(f"{'ID':<5}{'Name':<10}{'Salary':<10}")
for emp_id, name, salary in employees:
    print(f"{emp_id:<5}{name:<10}{salary:<10}")
