import math

num = int(input("Enter a number: "))

if num < 0:
    print("Square root of a negative number is not real.")
else:
    root = math.isqrt(num)
    if root * root != num:
        print(f"Square root of {num} is {math.sqrt(num):.4f}, which is not an integer, "
              "so it cannot be prime.")
    else:
        is_prime = root >= 2
        for i in range(2, math.isqrt(root) + 1):
            if root % i == 0:
                is_prime = False
                break
        if is_prime:
            print(f"Square root of {num} is {root}, which is a prime number.")
        else:
            print(f"Square root of {num} is {root}, which is not a prime number.")
