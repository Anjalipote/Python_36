"""
Question 5:
Create a set of student names. Ask the user to enter a name and check whether the student exists in the set.
"""

students = {"Amit", "Bhavna", "Chetan", "Divya"}
name = input("Enter student name: ").strip()
print(name, "exists in the set." if name in students else "does not exist in the set.")
