"""
Question 35:
Accept a paragraph and create a dictionary where key = word length and value = number of words having that length.
"""

import string

paragraph = input("Enter a paragraph: ")
counts = {}
for word in paragraph.split():
    word = word.strip(string.punctuation)
    if word:
        counts[len(word)] = counts.get(len(word), 0) + 1
for length in sorted(counts):
    print(f"Length {length}: {counts[length]} word(s)")
