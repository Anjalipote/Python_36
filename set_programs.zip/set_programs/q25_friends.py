"""
Question 25:
Friends of two users: mutual friends, unique to User 1, unique to User 2, total unique friends.
"""

user1 = {"Amit", "Bhavna", "Chetan", "Divya"}
user2 = {"Chetan", "Divya", "Esha", "Farhan"}
print("Mutual friends       :", user1 & user2)
print("Unique to User 1     :", user1 - user2)
print("Unique to User 2     :", user2 - user1)
print("Total unique friends :", len(user1 | user2))
