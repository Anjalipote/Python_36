"""
Question 14:
Create a tuple and delete it completely.
"""

t = (1, 2, 3)
print("Tuple:", t)
del t
try:
    print(t)
except NameError:
    print("The tuple has been deleted (NameError: name 't' is not defined).")
