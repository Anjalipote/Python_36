from abc import ABC, abstractmethod


class BankAccount(ABC):
    def __init__(self, acc_no, holder, balance):
        self.acc_no = acc_no
        self.holder = holder
        self.balance = balance

    @abstractmethod
    def deposit(self, amount):
        pass

    @abstractmethod
    def withdraw(self, amount):
        pass

    def show_balance(self):
        print(f"{self.holder} ({self.acc_no}) balance: Rs. {self.balance:.2f}")


class SavingsAccount(BankAccount):
    MIN_BALANCE = 500

    def deposit(self, amount):
        if amount <= 0:
            print("Invalid deposit amount.")
            return
        self.balance += amount
        print(f"Savings: Rs. {amount:.2f} deposited.")

    def withdraw(self, amount):
        if self.balance - amount < self.MIN_BALANCE:
            print(f"Savings: Withdrawal denied. Minimum balance Rs. {self.MIN_BALANCE} required.")
        else:
            self.balance -= amount
            print(f"Savings: Rs. {amount:.2f} withdrawn.")


class CurrentAccount(BankAccount):
    OVERDRAFT_LIMIT = 10000

    def deposit(self, amount):
        if amount <= 0:
            print("Invalid deposit amount.")
            return
        self.balance += amount
        print(f"Current: Rs. {amount:.2f} deposited.")

    def withdraw(self, amount):
        if self.balance - amount < -self.OVERDRAFT_LIMIT:
            print(f"Current: Overdraft limit of Rs. {self.OVERDRAFT_LIMIT} exceeded.")
        else:
            self.balance -= amount
            print(f"Current: Rs. {amount:.2f} withdrawn.")


sav = SavingsAccount(1001, "Anjali", 5000)
cur = CurrentAccount(2001, "Rohan", 2000)

for acc in (sav, cur):
    acc.show_balance()
    acc.deposit(1000)
    acc.withdraw(7000)
    acc.withdraw(5000)
    acc.show_balance()
    print()
