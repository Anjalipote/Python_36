"""
Question 3:
Create a dictionary of five products and their prices. Add a new product and price to the dictionary.
"""

products = {"Pen": 10, "Notebook": 50, "Bag": 800, "Bottle": 150, "Pencil": 5}
products["Eraser"] = 3
print("Updated products:", products)
