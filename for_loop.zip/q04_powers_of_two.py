# Prints 1 2 4 8 16 32 ... 2^n  (i.e. 2^0, 2^1, ..., 2^n)
n = int(input("Enter n: "))

term = 1
for i in range(n + 1):
    print(term, end=" ")
    term *= 2
print()
