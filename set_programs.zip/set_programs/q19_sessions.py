"""
Question 19:
Morning and afternoon sessions: find students present in both, only morning, only afternoon, and at least one session.
"""

morning = {"Amit", "Bhavna", "Chetan", "Divya"}
afternoon = {"Chetan", "Divya", "Esha", "Farhan"}
print("Present in both sessions   :", morning & afternoon)
print("Present only in the morning:", morning - afternoon)
print("Present only in afternoon  :", afternoon - morning)
print("Present in at least one    :", morning | afternoon)
