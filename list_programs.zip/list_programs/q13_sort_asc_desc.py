"""
Question 13:
Accept 10 numbers and sort them in ascending and descending order.
"""

numbers = []
for i in range(10):
    numbers.append(int(input(f"Enter number {i + 1}: ")))
print("Ascending order :", sorted(numbers))
print("Descending order:", sorted(numbers, reverse=True))
