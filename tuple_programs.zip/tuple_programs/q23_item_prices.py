"""
Question 23:
Store item prices in a tuple and calculate: total bill, average price, highest-priced item, lowest-priced item.
"""

prices = (120, 450, 80, 999, 250)
print("Total bill     :", sum(prices))
print("Average price  :", sum(prices) / len(prices))
print("Highest price  :", max(prices))
print("Lowest price   :", min(prices))
