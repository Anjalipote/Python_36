"""
Question 24:
Create a dictionary containing integers from 1 to 10 and their cubes.
"""

cubes = {n: n ** 3 for n in range(1, 11)}
print(cubes)
