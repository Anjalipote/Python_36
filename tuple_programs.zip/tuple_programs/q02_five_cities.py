"""
Question 2:
Create a tuple containing five city names. Display: first city, last city, third city.
"""

cities = ("Pune", "Mumbai", "Delhi", "Chennai", "Kolkata")
print("First city:", cities[0])
print("Last city :", cities[-1])
print("Third city:", cities[2])
