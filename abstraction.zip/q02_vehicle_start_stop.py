from abc import ABC, abstractmethod


class Vehicle(ABC):
    @abstractmethod
    def start(self):
        pass

    @abstractmethod
    def stop(self):
        pass


class Car(Vehicle):
    def start(self):
        print("Car: Engine started with push button.")

    def stop(self):
        print("Car: Engine stopped, handbrake applied.")


class Bike(Vehicle):
    def start(self):
        print("Bike: Engine started with self-start.")

    def stop(self):
        print("Bike: Engine stopped, side-stand down.")


class Bus(Vehicle):
    def start(self):
        print("Bus: Engine started with ignition key.")

    def stop(self):
        print("Bus: Engine stopped, doors opened.")


for v in (Car(), Bike(), Bus()):
    v.start()
    v.stop()
    print()
