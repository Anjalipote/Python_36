"""
Question 23:
Count the frequency of each element in a list.
"""

items = ["a", "b", "a", "c", "b", "a", "d"]
freq = {}
for x in items:
    freq[x] = freq.get(x, 0) + 1
for element, count in freq.items():
    print(f"{element} -> {count}")
