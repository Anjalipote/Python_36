"""
Question 11:
Create a dictionary containing student names and marks. Find the student who has scored the highest marks.
"""

marks = {"Amit": 85, "Bhavna": 92, "Chetan": 78, "Divya": 88}
topper = max(marks, key=marks.get)
print(f"Highest marks: {topper} ({marks[topper]})")
