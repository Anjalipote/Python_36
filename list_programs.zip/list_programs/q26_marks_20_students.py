"""
Question 26:
Store marks of 20 students in a list and determine: highest, lowest, average, number above average, number below average.
"""

marks = [67, 82, 45, 91, 73, 58, 88, 36, 94, 70, 62, 79, 85, 49, 55, 97, 66, 74, 81, 60]
average = sum(marks) / len(marks)
above = sum(1 for m in marks if m > average)
below = sum(1 for m in marks if m < average)
print("Highest marks :", max(marks))
print("Lowest marks  :", min(marks))
print("Average marks :", average)
print("Students above average:", above)
print("Students below average:", below)
