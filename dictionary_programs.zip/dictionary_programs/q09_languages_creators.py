"""
Question 9:
Create a dictionary of programming languages and their creators. Display each key and value using a loop.
"""

creators = {
    "Python": "Guido van Rossum",
    "Java": "James Gosling",
    "C": "Dennis Ritchie",
    "C++": "Bjarne Stroustrup",
}
for language, creator in creators.items():
    print(f"{language} was created by {creator}")
