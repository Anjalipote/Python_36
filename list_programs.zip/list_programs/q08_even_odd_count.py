"""
Question 8:
Store 15 integers in a list. Count how many numbers are even and how many are odd.
"""

numbers = [12, 7, 9, 22, 35, 40, 18, 5, 61, 74, 3, 28, 99, 50, 17]
even = odd = 0
for n in numbers:
    if n % 2 == 0:
        even += 1
    else:
        odd += 1
print("Even numbers:", even)
print("Odd numbers :", odd)
