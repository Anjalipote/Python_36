s = input("Enter a string: ")

count = {}
for ch in s:
    if ch != " ":
        count[ch] = count.get(ch, 0) + 1

duplicates = [ch for ch, c in count.items() if c > 1]

if duplicates:
    print("Duplicate characters:", " ".join(duplicates))
else:
    print("No duplicate characters found.")
