n = abs(int(input("Enter a number: ")))
original = n

total = 0
while n > 0:
    total += n % 10
    n //= 10

print(f"Sum of digits of {original} = {total}")
