import string

sentence = input("Enter a sentence: ")
target = input("Enter the word to count: ").lower()

count = 0
for w in sentence.split():
    if w.strip(string.punctuation).lower() == target:
        count += 1

print(f"'{target}' appears {count} time(s).")
