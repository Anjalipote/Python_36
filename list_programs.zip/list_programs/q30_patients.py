"""
Question 30:
Store patient names and ages using lists. Perform: add, delete, search, display all, count total patients.
"""

names = ["Ravi", "Sneha", "Kiran"]
ages = [45, 32, 60]
while True:
    print("\n--- Patient Records ---")
    print("1. Add patient\n2. Delete patient\n3. Search patient\n4. Display all\n5. Count patients\n6. Exit")
    choice = input("Enter your choice: ")
    if choice == "1":
        names.append(input("Enter patient name: "))
        ages.append(int(input("Enter patient age: ")))
        print("Patient added.")
    elif choice == "2":
        name = input("Enter patient name to delete: ")
        if name in names:
            i = names.index(name)
            names.pop(i)
            ages.pop(i)
            print("Patient deleted.")
        else:
            print("Patient not found.")
    elif choice == "3":
        name = input("Enter patient name to search: ")
        if name in names:
            print(f"Found: {name}, Age {ages[names.index(name)]}")
        else:
            print("Patient not found.")
    elif choice == "4":
        for n, a in zip(names, ages):
            print(f"{n} - {a} years")
    elif choice == "5":
        print("Total patients:", len(names))
    elif choice == "6":
        break
    else:
        print("Invalid choice.")
