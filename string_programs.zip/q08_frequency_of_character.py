s = input("Enter a string: ")
target = input("Enter the character to count: ")

count = 0
for ch in s:
    if ch == target:
        count += 1

print(f"'{target}' appears {count} time(s).")
