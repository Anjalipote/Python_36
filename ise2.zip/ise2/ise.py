
s = input("Enter a string: ")
ch = max(set(s), key =s.count)
print("most freq character", ch)