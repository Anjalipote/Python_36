"""
Question 9:
Create a list of cities. Ask the user to enter a city name and check whether it exists in the list.
"""

cities = ["Pune", "Mumbai", "Delhi", "Chennai", "Kolkata", "Bengaluru"]
city = input("Enter a city name: ").strip()
if city.lower() in [c.lower() for c in cities]:
    print(city, "exists in the list.")
else:
    print(city, "does not exist in the list.")
