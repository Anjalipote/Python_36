a = input("Enter first string: ")
b = input("Enter second string: ")


def clean(s):
    return sorted(ch.lower() for ch in s if ch != " ")


if clean(a) == clean(b):
    print(f"'{a}' and '{b}' are anagrams.")
else:
    print(f"'{a}' and '{b}' are not anagrams.")
