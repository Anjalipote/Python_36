s = input("Enter a string: ")
t = s.lower()

left, right = 0, len(t) - 1
is_palindrome = True
while left < right:
    if t[left] != t[right]:
        is_palindrome = False
        break
    left += 1
    right -= 1

if is_palindrome:
    print(f"'{s}' is a palindrome.")
else:
    print(f"'{s}' is not a palindrome.")
