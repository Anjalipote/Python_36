# Multilevel inheritance: Person -> Student -> ResearchStudent
# This version calls the parent constructors explicitly (ClassName.__init__).

class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age


class Student(Person):
    def __init__(self, name, age, roll_no, course):
        Person.__init__(self, name, age)
        self.roll_no = roll_no
        self.course = course


class ResearchStudent(Student):
    def __init__(self, name, age, roll_no, course, research_topic, guide_name):
        Student.__init__(self, name, age, roll_no, course)
        self.research_topic = research_topic
        self.guide_name = guide_name

    def show(self):
        print("Name           :", self.name)
        print("Age            :", self.age)
        print("Roll No        :", self.roll_no)
        print("Course         :", self.course)
        print("Research Topic :", self.research_topic)
        print("Guide Name     :", self.guide_name)


rs = ResearchStudent("Sana Khan", 27, 5102, "M.Phil Physics",
                     "Quantum Computing", "Dr. A. Rao")
rs.show()
