class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def display(self):
        print(f"Name           : {self.name}")
        print(f"Age            : {self.age}")


class Student(Person):
    def __init__(self, name, age, roll_no, course):
        super().__init__(name, age)
        self.roll_no = roll_no
        self.course = course

    def display(self):
        super().display()
        print(f"Roll No        : {self.roll_no}")
        print(f"Course         : {self.course}")


class ResearchStudent(Student):
    def __init__(self, name, age, roll_no, course, research_topic, guide_name):
        super().__init__(name, age, roll_no, course)
        self.research_topic = research_topic
        self.guide_name = guide_name

    def display(self):
        super().display()
        print(f"Research Topic : {self.research_topic}")
        print(f"Guide Name     : {self.guide_name}")


rs = ResearchStudent("Neha Verma", 26, 4501, "Ph.D. Computer Science",
                     "Machine Learning in Healthcare", "Dr. R. Iyer")
rs.display()
