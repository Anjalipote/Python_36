"""
Question 27:
Store salaries of employees and determine: highest, lowest, average, employees earning above Rs.50,000, employees earning below Rs.30,000.
"""

salaries = [25000, 48000, 52000, 31000, 75000, 29000, 60000, 45000]
print("Highest salary :", max(salaries))
print("Lowest salary  :", min(salaries))
print("Average salary :", sum(salaries) / len(salaries))
print("Earning above 50,000:", sum(1 for s in salaries if s > 50000))
print("Earning below 30,000:", sum(1 for s in salaries if s < 30000))
