"""
Question 17:
Create two 3 x 3 matrices using nested lists and perform matrix addition.
"""

A = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
B = [[9, 8, 7], [6, 5, 4], [3, 2, 1]]
result = [[0] * 3 for _ in range(3)]
for i in range(3):
    for j in range(3):
        result[i][j] = A[i][j] + B[i][j]
print("Sum of the matrices:")
for row in result:
    print(row)
