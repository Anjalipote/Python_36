"""
Question 12:
Create a dictionary containing student names and marks. Find the student with the lowest marks.
"""

marks = {"Amit": 85, "Bhavna": 92, "Chetan": 78, "Divya": 88}
lowest = min(marks, key=marks.get)
print(f"Lowest marks: {lowest} ({marks[lowest]})")
