s = input("Enter a string: ")

result = ""
for ch in s:
    if ch not in result:
        result += ch   # keep only the first occurrence, order preserved

print("After removing duplicates:", result)
