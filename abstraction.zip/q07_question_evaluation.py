from abc import ABC, abstractmethod


class Question(ABC):
    def __init__(self, text, marks):
        self.text = text
        self.marks = marks

    @abstractmethod
    def evaluate_answer(self, answer):
        """Return marks awarded for the given answer."""
        pass


class MCQQuestion(Question):
    def __init__(self, text, marks, options, correct_option):
        super().__init__(text, marks)
        self.options = options
        self.correct_option = correct_option

    def evaluate_answer(self, answer):
        return self.marks if answer.strip().upper() == self.correct_option.upper() else 0


class TrueFalseQuestion(Question):
    def __init__(self, text, marks, correct_answer):
        super().__init__(text, marks)
        self.correct_answer = correct_answer  # True / False

    def evaluate_answer(self, answer):
        given = answer.strip().lower() in ("true", "t", "yes")
        return self.marks if given == self.correct_answer else 0


class DescriptiveQuestion(Question):
    def __init__(self, text, marks, keywords):
        super().__init__(text, marks)
        self.keywords = keywords

    def evaluate_answer(self, answer):
        # Marks are given in proportion to the keywords found in the answer
        found = sum(1 for k in self.keywords if k.lower() in answer.lower())
        return round(self.marks * found / len(self.keywords), 2)


tests = [
    (MCQQuestion("Which keyword defines a class in Python?", 2,
                 ["A. def", "B. class", "C. object", "D. self"], "B"), "b"),
    (TrueFalseQuestion("Python supports multiple inheritance.", 1, True), "True"),
    (DescriptiveQuestion("Define encapsulation.", 5,
                         ["data", "methods", "bundling", "access"]),
     "Encapsulation is bundling of data and methods into one unit."),
]

total = 0
for q, ans in tests:
    score = q.evaluate_answer(ans)
    total += score
    print(f"{q.__class__.__name__:<20} | {q.text}")
    print(f"  Answer: {ans}")
    print(f"  Marks : {score} / {q.marks}\n")

print(f"Total score: {total}")
