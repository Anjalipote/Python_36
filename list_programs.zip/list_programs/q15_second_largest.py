"""
Question 15:
Find the second largest element in a list.
"""

numbers = [12, 45, 2, 41, 45, 31, 10]
distinct = sorted(set(numbers))
if len(distinct) < 2:
    print("There is no second largest element.")
else:
    print("List           :", numbers)
    print("Second largest :", distinct[-2])
