"""
Question 6:
Create a tuple with repeated numbers and count how many times a particular number appears.
"""

numbers = (1, 2, 3, 2, 4, 2, 5, 3)
n = int(input("Enter the number to count: "))
print(f"{n} appears {numbers.count(n)} time(s).")
