import numpy as np

A = np.array([[1,2,3],
              [4,5,6],
              [7,8,9]])

B = np.array([[1,2,3],
              [4,5,6],
              [7,8,9]])


print("Element wise-multiplication\n",A*B)
print("Addition\n",A+B)
print("Subtraction\n",A-B)
print("Matrix multiplication\n", A@B)
















