"""
Question 20:
Students enrolled in Python and Java: find students enrolled in both courses and students enrolled in only one course.
"""

python = {"Amit", "Bhavna", "Chetan", "Divya"}
java = {"Chetan", "Divya", "Esha", "Farhan"}
print("Enrolled in both courses :", python & java)
print("Enrolled in only one     :", python ^ java)
