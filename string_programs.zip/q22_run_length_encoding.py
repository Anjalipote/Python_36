s = input("Enter a string: ")

encoded = ""
i = 0
while i < len(s):
    count = 1
    while i + count < len(s) and s[i + count] == s[i]:
        count += 1
    encoded += s[i] + str(count)
    i += count

print("Encoded string:", encoded)
