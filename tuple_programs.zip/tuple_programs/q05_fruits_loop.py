"""
Question 5:
Create a tuple of fruits and display each fruit using a loop.
"""

fruits = ("apple", "banana", "mango", "orange")
for fruit in fruits:
    print(fruit)
