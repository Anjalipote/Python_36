"""
Question 20:
Create a dictionary and display its elements in ascending order of keys.
"""

data = {5: "five", 2: "two", 9: "nine", 1: "one"}
for key in sorted(data):
    print(key, "->", data[key])
