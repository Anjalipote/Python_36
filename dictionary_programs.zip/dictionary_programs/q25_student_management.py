"""
Question 25:
Student marks dictionary: add a student, update marks, delete a student, search for a student, display all students, find the highest marks, calculate the average.
"""

students = {"Amit": 85, "Bhavna": 92, "Chetan": 78}
while True:
    print("\n--- Student Management ---")
    print("1. Add student\n2. Update marks\n3. Delete student\n4. Search student")
    print("5. Display all\n6. Highest marks\n7. Average marks\n8. Exit")
    choice = input("Enter your choice: ")
    if choice == "1":
        name = input("Enter name: ")
        students[name] = int(input("Enter marks: "))
        print("Student added.")
    elif choice == "2":
        name = input("Enter name: ")
        if name in students:
            students[name] = int(input("Enter new marks: "))
            print("Marks updated.")
        else:
            print("Student not found.")
    elif choice == "3":
        name = input("Enter name: ")
        if students.pop(name, None) is not None:
            print("Student deleted.")
        else:
            print("Student not found.")
    elif choice == "4":
        name = input("Enter name: ")
        print(f"{name}: {students[name]}" if name in students else "Student not found.")
    elif choice == "5":
        for name, m in students.items():
            print(f"{name}: {m}")
    elif choice == "6":
        if students:
            top = max(students, key=students.get)
            print(f"Highest marks: {top} ({students[top]})")
        else:
            print("No students.")
    elif choice == "7":
        if students:
            print("Average marks:", sum(students.values()) / len(students))
        else:
            print("No students.")
    elif choice == "8":
        break
    else:
        print("Invalid choice.")
