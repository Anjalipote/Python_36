"""
Question 12:
Display all elements present at even index positions.
"""

numbers = [11, 22, 33, 44, 55, 66, 77, 88]
print("Elements at even index positions:")
for i in range(0, len(numbers), 2):
    print(f"Index {i}: {numbers[i]}")
