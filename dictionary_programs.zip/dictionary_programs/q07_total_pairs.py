"""
Question 7:
Create a dictionary containing student records and find the total number of key-value pairs.
"""

records = {101: "Amit", 102: "Bhavna", 103: "Chetan", 104: "Divya"}
print("Total key-value pairs:", len(records))
