"""
Question 29:
Store the temperature of 30 days and determine: hottest day, coldest day, average temperature, days above average, days below average.
"""

temps = [28, 30, 31, 33, 35, 36, 34, 32, 31, 29,
         27, 26, 28, 30, 32, 34, 37, 38, 36, 35,
         33, 31, 30, 29, 28, 27, 29, 31, 33, 34]
average = sum(temps) / len(temps)
hottest_day = temps.index(max(temps)) + 1
coldest_day = temps.index(min(temps)) + 1
print(f"Hottest day : Day {hottest_day} ({max(temps)} C)")
print(f"Coldest day : Day {coldest_day} ({min(temps)} C)")
print(f"Average temperature: {average:.2f} C")
print("Days above average :", sum(1 for t in temps if t > average))
print("Days below average :", sum(1 for t in temps if t < average))
