"""
Question 1:
Create a set containing five integers and display all its elements.
"""

numbers = {10, 20, 30, 40, 50}
print("Set elements:", numbers)
