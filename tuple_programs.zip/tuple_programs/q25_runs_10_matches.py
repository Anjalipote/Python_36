"""
Question 25:
Store runs scored in 10 matches and calculate: total, highest, lowest, average.
"""

runs = (102, 45, 67, 12, 130, 55, 0, 89, 101, 34)
print("Total runs   :", sum(runs))
print("Highest score:", max(runs))
print("Lowest score :", min(runs))
print("Average score:", sum(runs) / len(runs))
