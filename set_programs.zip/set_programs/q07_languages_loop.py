"""
Question 7:
Create a set of programming languages and display each language using a for loop.
"""

languages = {"Python", "Java", "C", "C++", "JavaScript"}
for lang in languages:
    print(lang)
