class Person:
    def __init__(self, name, age, **kwargs):
        super().__init__(**kwargs)
        self.name = name
        self.age = age

    def display(self):
        print(f"Name           : {self.name}")
        print(f"Age            : {self.age}")


class Doctor(Person):  # hierarchical: Person -> Doctor
    def __init__(self, specialization, **kwargs):
        super().__init__(**kwargs)
        self.specialization = specialization

    def display(self):
        super().display()
        print(f"Specialization : {self.specialization}")

    def treat(self):
        print(f"Dr. {self.name} is treating patients.")


class Patient(Person):  # hierarchical: Person -> Patient
    def __init__(self, disease, **kwargs):
        super().__init__(**kwargs)
        self.disease = disease

    def display(self):
        super().display()
        print(f"Disease        : {self.disease}")


class Researcher(Person):  # helper class used for multiple inheritance
    def __init__(self, research_area, **kwargs):
        super().__init__(**kwargs)
        self.research_area = research_area

    def display(self):
        super().display()
        print(f"Research Area  : {self.research_area}")


class Surgeon(Doctor):  # multilevel: Person -> Doctor -> Surgeon
    def __init__(self, surgeries_done, **kwargs):
        super().__init__(**kwargs)
        self.surgeries_done = surgeries_done

    def display(self):
        super().display()
        print(f"Surgeries Done : {self.surgeries_done}")

    def operate(self):
        print(f"Dr. {self.name} is performing a surgery.")


class MedicalResearcher(Doctor, Researcher):  # multiple inheritance
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def conduct_research(self):
        print(f"Dr. {self.name} is researching {self.research_area}.")


print("--- Patient ---")
Patient(name="Ramesh", age=52, disease="Hypertension").display()

print("\n--- Surgeon ---")
sg = Surgeon(name="Meera Rao", age=45, specialization="Cardiac Surgery", surgeries_done=850)
sg.display()
sg.treat()
sg.operate()

print("\n--- Medical Researcher ---")
mr = MedicalResearcher(name="Arjun Das", age=41, specialization="Oncology",
                       research_area="Cancer Immunotherapy")
mr.display()
mr.treat()
mr.conduct_research()

print("\nMRO of MedicalResearcher:",
      " -> ".join(c.__name__ for c in MedicalResearcher.__mro__))
