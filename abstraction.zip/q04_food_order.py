from abc import ABC, abstractmethod


class FoodOrder(ABC):
    GST_RATE = 0.05

    def __init__(self, customer, item, quantity, price):
        self.customer = customer
        self.item = item
        self.quantity = quantity
        self.price = price

    @abstractmethod
    def delivery_charge(self):
        pass

    @abstractmethod
    def calculate_bill(self):
        pass

    def show(self):
        print(f"Customer : {self.customer}")
        print(f"Item     : {self.item} x {self.quantity}")
        print(f"Delivery : Rs. {self.delivery_charge():.2f}")
        print(f"Total    : Rs. {self.calculate_bill():.2f}\n")


class RestaurantOrder(FoodOrder):
    def delivery_charge(self):
        return 0  # dine-in, no delivery

    def calculate_bill(self):
        subtotal = self.price * self.quantity
        return subtotal + subtotal * self.GST_RATE + self.delivery_charge()


class HomeDeliveryOrder(FoodOrder):
    def __init__(self, customer, item, quantity, price, distance_km):
        super().__init__(customer, item, quantity, price)
        self.distance_km = distance_km

    def delivery_charge(self):
        return 30 + 10 * self.distance_km  # base Rs. 30 + Rs. 10 per km

    def calculate_bill(self):
        subtotal = self.price * self.quantity
        return subtotal + subtotal * self.GST_RATE + self.delivery_charge()


RestaurantOrder("Aarav", "Veg Biryani", 2, 220).show()
HomeDeliveryOrder("Diya", "Paneer Pizza", 1, 350, 4).show()
