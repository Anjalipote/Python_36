"""
Question 11:
Convert a tuple into a list and add a new element.
"""

t = (1, 2, 3)
lst = list(t)
lst.append(4)
print("Tuple :", t)
print("List after adding element:", lst)
