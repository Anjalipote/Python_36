"""
Question 21:
Store student details in a tuple: Roll Number, Name, Department, Marks. Display all the details.
"""

student = (101, "Amit", "Computer Science", 85)
roll, name, dept, marks = student
print("Roll Number:", roll)
print("Name       :", name)
print("Department :", dept)
print("Marks      :", marks)
