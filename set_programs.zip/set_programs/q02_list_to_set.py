"""
Question 2:
Create a list containing duplicate values. Convert the list into a set and display the resulting set.
"""

numbers = [1, 2, 2, 3, 4, 4, 5]
unique = set(numbers)
print("List:", numbers)
print("Set :", unique)
