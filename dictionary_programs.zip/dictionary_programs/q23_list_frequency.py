"""
Question 23:
Given a list of numbers, create a dictionary containing each unique number and its frequency.
"""

numbers = [1, 2, 2, 3, 3, 3, 4, 1]
freq = {}
for n in numbers:
    freq[n] = freq.get(n, 0) + 1
print(freq)
