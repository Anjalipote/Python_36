"""
Question 7:
Create a tuple of employee IDs and find the index of a given ID.
"""

emp_ids = (101, 102, 103, 104, 105)
emp_id = int(input("Enter employee ID: "))
if emp_id in emp_ids:
    print("Index of", emp_id, "is", emp_ids.index(emp_id))
else:
    print("Employee ID not found.")
