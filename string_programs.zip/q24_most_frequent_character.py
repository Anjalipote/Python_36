s = input("Enter a string: ")

freq = {}
for ch in s:
    if ch != " ":
        freq[ch] = freq.get(ch, 0) + 1

if not freq:
    print("No characters entered.")
else:
    best = None
    for ch, c in freq.items():
        if best is None or c > freq[best]:   # on a tie the earlier character wins
            best = ch
    print(f"Most frequent character: '{best}' (appears {freq[best]} times)")
