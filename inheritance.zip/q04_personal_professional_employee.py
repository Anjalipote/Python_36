class PersonalDetails:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def show_personal(self):
        print(f"Name        : {self.name}")
        print(f"Age         : {self.age}")


class ProfessionalDetails:
    def __init__(self, emp_id, designation, salary):
        self.emp_id = emp_id
        self.designation = designation
        self.salary = salary

    def show_professional(self):
        print(f"Employee ID : {self.emp_id}")
        print(f"Designation : {self.designation}")
        print(f"Salary      : Rs. {self.salary:.2f}")


class Employee(PersonalDetails, ProfessionalDetails):
    def __init__(self, name, age, emp_id, designation, salary):
        PersonalDetails.__init__(self, name, age)
        ProfessionalDetails.__init__(self, emp_id, designation, salary)

    def display(self):
        print("--- Complete Employee Information ---")
        self.show_personal()
        self.show_professional()


emp = Employee("Priya Sharma", 29, 301, "Software Developer", 65000)
emp.display()
