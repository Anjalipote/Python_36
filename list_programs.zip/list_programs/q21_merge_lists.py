"""
Question 21:
Accept two lists and merge them into a single list.
"""

list1 = input("Enter elements of the first list (space separated): ").split()
list2 = input("Enter elements of the second list (space separated): ").split()
merged = list1 + list2
print("Merged list:", merged)
