class Printer:
    def print_document(self, doc):
        print(f"Printing '{doc}' ...")


class Scanner:
    def scan_document(self, doc):
        print(f"Scanning '{doc}' ...")


class MultifunctionDevice(Printer, Scanner):
    def copy_document(self, doc):
        self.scan_document(doc)
        self.print_document(doc)
        print("Copy completed.")


device = MultifunctionDevice()
device.print_document("Report.pdf")
device.scan_document("Certificate.jpg")
print()
device.copy_document("Invoice.docx")
