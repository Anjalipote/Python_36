s = input("Enter a string: ")

if s == "":
    print("The string is empty.")
else:
    print("First character:", s[0])
    print("Last character :", s[-1])
