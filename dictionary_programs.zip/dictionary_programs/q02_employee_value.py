"""
Question 2:
Create a dictionary containing employee information and display the value associated with a specified key.
"""

employee = {"id": 1, "name": "Ravi", "department": "Sales", "salary": 45000}
key = input("Enter the key to look up: ").strip()
if key in employee:
    print(f"{key} -> {employee[key]}")
else:
    print("Key not found.")
