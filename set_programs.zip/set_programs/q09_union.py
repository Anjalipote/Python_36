"""
Question 9:
Create two sets of integers and find their union.
"""

a = {1, 2, 3, 4}
b = {3, 4, 5, 6}
print("Union:", a | b)          # same as a.union(b)
