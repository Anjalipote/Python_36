"""
Question 16:
Create two sets and check whether they are equal.
"""

a = {1, 2, 3}
b = {3, 2, 1}
print("Sets are equal." if a == b else "Sets are not equal.")
