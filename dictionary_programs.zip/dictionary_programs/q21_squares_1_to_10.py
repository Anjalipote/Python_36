"""
Question 21:
Create a dictionary containing numbers from 1 to 10 as keys and their squares as values.
"""

squares = {n: n ** 2 for n in range(1, 11)}
print(squares)
