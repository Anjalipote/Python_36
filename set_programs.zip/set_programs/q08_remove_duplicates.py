"""
Question 8:
Create a list containing duplicate numbers, use a set to remove the duplicates.
"""

numbers = [5, 3, 5, 2, 3, 8, 2, 9]
print("Original list      :", numbers)
print("After removing duplicates:", list(set(numbers)))
