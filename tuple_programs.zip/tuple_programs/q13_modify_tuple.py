"""
Question 13:
Modify a tuple by converting it into a list and then back into a tuple.
"""

t = (10, 20, 30, 40)
print("Original tuple:", t)
lst = list(t)
lst[1] = 25
lst.append(50)
t = tuple(lst)
print("Modified tuple:", t)
