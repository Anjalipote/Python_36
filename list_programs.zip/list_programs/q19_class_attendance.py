"""
Question 19:
Store names of students present in class. Display total students, search a student's attendance, add a new student, remove an absent student.
"""

present = ["Amit", "Bhavna", "Chetan", "Divya", "Esha"]
while True:
    print("\n--- Attendance ---")
    print("1. Total students\n2. Search attendance\n3. Add new student\n4. Remove absent student\n5. Display all\n6. Exit")
    choice = input("Enter your choice: ")
    if choice == "1":
        print("Total students present:", len(present))
    elif choice == "2":
        name = input("Enter student name: ")
        print(name, "is present." if name in present else "is not marked present.")
    elif choice == "3":
        present.append(input("Enter new student name: "))
        print("Student added.")
    elif choice == "4":
        name = input("Enter absent student name: ")
        if name in present:
            present.remove(name)
            print("Student removed.")
        else:
            print("Student not found in the list.")
    elif choice == "5":
        print("Present students:", present)
    elif choice == "6":
        break
    else:
        print("Invalid choice.")
