"""
Question 13:
Create a dictionary containing student names and marks. Calculate the average marks of all students.
"""

marks = {"Amit": 85, "Bhavna": 92, "Chetan": 78, "Divya": 88}
print("Average marks:", sum(marks.values()) / len(marks))
