import string

password = input("Enter a password: ")

has_upper = has_lower = has_digit = has_special = False
for ch in password:
    if ch.isupper():
        has_upper = True
    elif ch.islower():
        has_lower = True
    elif ch.isdigit():
        has_digit = True
    elif ch in string.punctuation:
        has_special = True

problems = []
if len(password) < 8:
    problems.append("must be at least 8 characters long")
if not has_upper:
    problems.append("needs at least one uppercase letter")
if not has_lower:
    problems.append("needs at least one lowercase letter")
if not has_digit:
    problems.append("needs at least one digit")
if not has_special:
    problems.append("needs at least one special character")

if problems:
    print("Invalid password:")
    for p in problems:
        print(" -", p)
else:
    print("Valid password.")
