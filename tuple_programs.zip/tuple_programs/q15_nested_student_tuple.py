"""
Question 15:
Create a nested tuple containing student details and display each record.
"""

students = (
    (101, "Amit", "Computer", 85),
    (102, "Bhavna", "IT", 92),
    (103, "Chetan", "Electronics", 78),
)
for record in students:
    print(record)
