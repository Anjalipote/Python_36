sentence = input("Enter a sentence: ")

words = sentence.split()
if not words:
    print("No words entered.")
else:
    longest = words[0]
    for w in words:
        if len(w) > len(longest):
            longest = w
    print(f"Longest word: {longest} ({len(longest)} letters)")
