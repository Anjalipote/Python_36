"""
Question 14:
Accept a string from the user and create a dictionary containing each character and its frequency.
"""

text = input("Enter a string: ")
freq = {}
for ch in text:
    freq[ch] = freq.get(ch, 0) + 1
print(freq)
