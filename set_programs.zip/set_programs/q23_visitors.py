"""
Question 23:
Visitor IDs from two days: unique visitors across both days, returning visitors, only first day, only second day.
"""

day1 = {101, 102, 103, 104, 105}
day2 = {104, 105, 106, 107}
print("Unique visitors across both days:", day1 | day2)
print("Returning visitors              :", day1 & day2)
print("Only on the first day           :", day1 - day2)
print("Only on the second day          :", day2 - day1)
