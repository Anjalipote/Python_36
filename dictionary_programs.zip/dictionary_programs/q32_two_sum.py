"""
Question 32:
Take a list of integers and a target value, find two numbers whose sum is equal to the target using a dictionary.
"""

numbers = [2, 7, 11, 15, 3, 6]
target = int(input("Enter the target value: "))
seen = {}                      # number -> index
found = False
for i, n in enumerate(numbers):
    complement = target - n
    if complement in seen:
        print(f"Numbers: {complement} + {n} = {target}  (indices {seen[complement]} and {i})")
        found = True
        break
    seen[n] = i
if not found:
    print("No two numbers add up to the target.")
