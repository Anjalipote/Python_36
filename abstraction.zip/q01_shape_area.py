from abc import ABC, abstractmethod
import math


class Shape(ABC):
    @abstractmethod
    def area(self):
        pass


class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return math.pi * self.radius ** 2


class Rectangle(Shape):
    def __init__(self, length, breadth):
        self.length = length
        self.breadth = breadth

    def area(self):
        return self.length * self.breadth


class Triangle(Shape):
    def __init__(self, base, height):
        self.base = base
        self.height = height

    def area(self):
        return 0.5 * self.base * self.height


# Shape itself cannot be instantiated
try:
    Shape()
except TypeError as e:
    print("Cannot create object of abstract class:", e, "\n")

for s in (Circle(7), Rectangle(5, 3), Triangle(6, 4)):
    print(f"{s.__class__.__name__:<10} area = {s.area():.2f}")
