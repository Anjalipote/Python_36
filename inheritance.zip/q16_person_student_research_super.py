# Multilevel inheritance: Person -> Student -> ResearchStudent
# This version uses super() and shows the inheritance chain.

class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def __str__(self):
        return f"{self.name}, age {self.age}"


class Student(Person):
    def __init__(self, name, age, roll_no, course):
        super().__init__(name, age)
        self.roll_no = roll_no
        self.course = course

    def __str__(self):
        return f"{super().__str__()}, Roll No {self.roll_no}, Course {self.course}"


class ResearchStudent(Student):
    def __init__(self, name, age, roll_no, course, research_topic, guide_name):
        super().__init__(name, age, roll_no, course)
        self.research_topic = research_topic
        self.guide_name = guide_name

    def __str__(self):
        return (f"{super().__str__()}, Topic '{self.research_topic}', "
                f"Guide {self.guide_name}")


rs = ResearchStudent("Vikram Singh", 28, 6203, "Ph.D. Electronics",
                     "IoT Security", "Dr. S. Nair")
print(rs)
print("Is Student?", isinstance(rs, Student))
print("Is Person? ", isinstance(rs, Person))
print("Chain:", " -> ".join(c.__name__ for c in reversed(ResearchStudent.__mro__[:-1])))
