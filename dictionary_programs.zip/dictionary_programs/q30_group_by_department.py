"""
Question 30:
Take a dictionary of student names and departments; create a new dictionary that groups students according to their department.
"""

students = {"Amit": "CS", "Bhavna": "IT", "Chetan": "CS", "Divya": "ENTC", "Esha": "IT"}
groups = {}
for name, dept in students.items():
    groups.setdefault(dept, []).append(name)
print(groups)
