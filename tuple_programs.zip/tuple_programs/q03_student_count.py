"""
Question 3:
Create a tuple of student names and display the total number of students using len().
"""

students = ("Amit", "Bhavna", "Chetan", "Divya")
print("Total number of students:", len(students))
