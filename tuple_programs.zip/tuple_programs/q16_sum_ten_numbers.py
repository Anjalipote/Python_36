"""
Question 16:
Store ten numbers in a tuple and calculate their sum.
"""

t = (5, 10, 15, 20, 25, 30, 35, 40, 45, 50)
total = 0
for n in t:
    total += n
print("Sum:", total)
