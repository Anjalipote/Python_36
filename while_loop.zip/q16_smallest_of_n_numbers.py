n = int(input("How many numbers? "))

if n <= 0:
    print("Please enter a positive count.")
else:
    smallest = float(input("Enter number 1: "))
    i = 2
    while i <= n:
        num = float(input(f"Enter number {i}: "))
        if num < smallest:
            smallest = num
        i += 1
    print("Smallest number =", smallest)
