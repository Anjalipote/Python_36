a = input("Enter first string: ")
b = input("Enter second string: ")

# b is a rotation of a only if the lengths match and b occurs inside a + a
if len(a) == len(b) and b in a + a:
    print("Yes")
else:
    print("No")
