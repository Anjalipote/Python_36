"""
Question 18:
Create a shopping cart using a list. Perform: add item, remove item, search item, display cart, count total items.
"""

cart = []
while True:
    print("\n--- Shopping Cart ---")
    print("1. Add item\n2. Remove item\n3. Search item\n4. Display cart\n5. Count total items\n6. Exit")
    choice = input("Enter your choice: ")
    if choice == "1":
        cart.append(input("Enter item to add: "))
        print("Item added.")
    elif choice == "2":
        item = input("Enter item to remove: ")
        if item in cart:
            cart.remove(item)
            print("Item removed.")
        else:
            print("Item not found.")
    elif choice == "3":
        item = input("Enter item to search: ")
        print("Item found." if item in cart else "Item not found.")
    elif choice == "4":
        print("Cart:", cart if cart else "empty")
    elif choice == "5":
        print("Total items:", len(cart))
    elif choice == "6":
        print("Goodbye!")
        break
    else:
        print("Invalid choice.")
