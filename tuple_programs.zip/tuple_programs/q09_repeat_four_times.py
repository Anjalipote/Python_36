"""
Question 9:
Create a tuple containing three elements and repeat it four times.
"""

t = ("a", "b", "c")
print("Repeated tuple:", t * 4)
