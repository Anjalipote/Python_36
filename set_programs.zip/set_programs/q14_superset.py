"""
Question 14:
Determine whether the first set is a superset of the second set.
"""

a = {1, 2, 3, 4, 5}
b = {2, 3}
print("First set is a superset of the second set:", a.issuperset(b))
