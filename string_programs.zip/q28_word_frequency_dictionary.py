import string

paragraph = input("Enter a paragraph: ")

freq = {}
for w in paragraph.split():
    w = w.strip(string.punctuation).lower()
    if w:
        freq[w] = freq.get(w, 0) + 1

print("\nWord frequency dictionary:")
print(freq)
print()
for word, c in freq.items():
    print(f"{word:<12} : {c}")
