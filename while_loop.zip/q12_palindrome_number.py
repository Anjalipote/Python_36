n = int(input("Enter a number: "))

temp = abs(n)
reverse = 0
while temp > 0:
    reverse = reverse * 10 + temp % 10
    temp //= 10

if n >= 0 and reverse == n:
    print(f"{n} is a palindrome.")
else:
    print(f"{n} is not a palindrome.")
