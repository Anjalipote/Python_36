def caesar(text, shift):
    result = ""
    for ch in text:
        if ch.isalpha():
            base = ord("A") if ch.isupper() else ord("a")
            result += chr((ord(ch) - base + shift) % 26 + base)
        else:
            result += ch   # digits, spaces and symbols stay unchanged
    return result


print("1. Encrypt")
print("2. Decrypt")
choice = input("Enter your choice (1/2): ")
message = input("Enter the message: ")
shift = int(input("Enter the shift value: "))

if choice == "1":
    print("Encrypted message:", caesar(message, shift))
elif choice == "2":
    print("Decrypted message:", caesar(message, -shift))
else:
    print("Invalid choice.")
