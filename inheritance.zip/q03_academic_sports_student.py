class Academic:
    def __init__(self, marks):
        self.marks = marks  # out of 100

    def show_marks(self):
        print(f"Academic marks : {self.marks}")


class Sports:
    def __init__(self, points):
        self.points = points  # out of 100

    def show_points(self):
        print(f"Sports points  : {self.points}")


class Student(Academic, Sports):
    def __init__(self, name, marks, points):
        Academic.__init__(self, marks)
        Sports.__init__(self, points)
        self.name = name

    def overall_performance(self):
        # 70% weightage to academics, 30% to sports
        return 0.7 * self.marks + 0.3 * self.points

    def display(self):
        print(f"Student Name   : {self.name}")
        self.show_marks()
        self.show_points()
        print(f"Overall performance: {self.overall_performance():.2f} / 100")


s = Student("Aarav", 88, 75)
s.display()
