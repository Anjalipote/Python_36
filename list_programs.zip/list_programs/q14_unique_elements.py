"""
Question 14:
Create a list containing duplicate values and display only unique elements.
"""

numbers = [1, 2, 2, 3, 4, 4, 5, 1, 6]
unique = []
for n in numbers:
    if n not in unique:
        unique.append(n)
print("Original list  :", numbers)
print("Unique elements:", unique)
