"""
Question 5:
Create a list of student names. Remove the first student, the last student and a specific student by name. Display the remaining list.
"""

students = ["Amit", "Bhavna", "Chetan", "Divya", "Esha", "Farhan"]
students.pop(0)            # first student
students.pop()             # last student
students.remove("Chetan")  # specific student by name
print("Remaining students:", students)
