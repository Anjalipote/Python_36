# A B C
# A B C
# A B C
for row in range(3):
    for col in range(3):
        print(chr(65 + col), end=" ")
    print()
