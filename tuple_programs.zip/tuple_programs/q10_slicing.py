"""
Question 10:
Create a tuple of 10 numbers and display: first five, last five, middle four, alternate elements, reverse tuple.
"""

t = (10, 20, 30, 40, 50, 60, 70, 80, 90, 100)
print("First five elements :", t[:5])
print("Last five elements  :", t[-5:])
print("Middle four elements:", t[3:7])
print("Alternate elements  :", t[::2])
print("Reverse tuple       :", t[::-1])
