"""
Question 28:
Names and phone numbers: add contact, search contact, update contact, delete contact, display all contacts.
"""

contacts = {"Amit": "9876543210", "Bhavna": "9123456780"}
while True:
    print("\n--- Contacts ---")
    print("1. Add contact\n2. Search contact\n3. Update contact\n4. Delete contact\n5. Display all\n6. Exit")
    choice = input("Enter your choice: ")
    if choice == "1":
        name = input("Enter name: ")
        contacts[name] = input("Enter phone number: ")
        print("Contact added.")
    elif choice == "2":
        name = input("Enter name: ")
        print(f"{name}: {contacts[name]}" if name in contacts else "Contact not found.")
    elif choice == "3":
        name = input("Enter name: ")
        if name in contacts:
            contacts[name] = input("Enter new phone number: ")
            print("Contact updated.")
        else:
            print("Contact not found.")
    elif choice == "4":
        name = input("Enter name: ")
        if contacts.pop(name, None) is not None:
            print("Contact deleted.")
        else:
            print("Contact not found.")
    elif choice == "5":
        for name, phone in contacts.items():
            print(f"{name}: {phone}")
    elif choice == "6":
        break
    else:
        print("Invalid choice.")
