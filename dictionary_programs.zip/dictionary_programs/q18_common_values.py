"""
Question 18:
Given two dictionaries, identify the values that are common to both dictionaries.
"""

d1 = {"a": 1, "b": 2, "c": 3}
d2 = {"x": 2, "y": 3, "z": 4}
print("Common values:", set(d1.values()) & set(d2.values()))
