"""
Question 6:
Create a dictionary of employee IDs and names. Ask the user for an employee ID and check whether it exists.
"""

employees = {101: "Ravi", 102: "Sneha", 103: "Kiran"}
emp_id = int(input("Enter employee ID: "))
if emp_id in employees:
    print("Employee found:", employees[emp_id])
else:
    print("Employee ID does not exist.")
