"""
Question 12:
Accept five numbers from the user, store them in a list, and convert the list into a tuple.
"""

numbers = []
for i in range(5):
    numbers.append(int(input(f"Enter number {i + 1}: ")))
print("List :", numbers)
print("Tuple:", tuple(numbers))
