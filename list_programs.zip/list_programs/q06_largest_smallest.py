"""
Question 6:
Find the largest and smallest number in a list without using max() or min().
"""

numbers = [45, 12, 89, 3, 67, 21, 90, 5]
largest = smallest = numbers[0]
for n in numbers:
    if n > largest:
        largest = n
    if n < smallest:
        smallest = n
print("List     :", numbers)
print("Largest  :", largest)
print("Smallest :", smallest)
