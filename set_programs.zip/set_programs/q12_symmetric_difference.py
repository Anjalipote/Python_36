"""
Question 12:
Find the elements present in either set but not in both.
"""

a = {1, 2, 3, 4}
b = {3, 4, 5, 6}
print("Symmetric difference:", a ^ b)   # same as a.symmetric_difference(b)
