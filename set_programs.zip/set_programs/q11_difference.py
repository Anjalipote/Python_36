"""
Question 11:
Create two sets and find elements present in the first but not the second, and in the second but not the first.
"""

a = {1, 2, 3, 4}
b = {3, 4, 5, 6}
print("In first but not second:", a - b)
print("In second but not first:", b - a)
