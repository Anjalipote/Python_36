"""
Question 10:
Create two sets and find the elements common to both sets.
"""

a = {1, 2, 3, 4}
b = {3, 4, 5, 6}
print("Common elements:", a & b)    # same as a.intersection(b)
