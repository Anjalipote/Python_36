n = int(input("Enter n: "))

total = 0
i = 2
while i <= n:
    total += i
    i += 2

print(f"Sum of even numbers up to {n} = {total}")
