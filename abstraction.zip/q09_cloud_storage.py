from abc import ABC, abstractmethod


class CloudStorage(ABC):
    def __init__(self):
        self._files = {}  # simulated storage: filename -> content

    @abstractmethod
    def upload_file(self, filename, content):
        pass

    @abstractmethod
    def download_file(self, filename):
        pass

    @abstractmethod
    def delete_file(self, filename):
        pass


class GoogleDrive(CloudStorage):
    def upload_file(self, filename, content):
        self._files[filename] = content
        print(f"[Google Drive] Uploaded '{filename}'.")

    def download_file(self, filename):
        if filename in self._files:
            print(f"[Google Drive] Downloaded '{filename}': {self._files[filename]}")
        else:
            print(f"[Google Drive] '{filename}' not found.")

    def delete_file(self, filename):
        if self._files.pop(filename, None) is not None:
            print(f"[Google Drive] Moved '{filename}' to Trash.")
        else:
            print(f"[Google Drive] '{filename}' not found.")


class Dropbox(CloudStorage):
    def upload_file(self, filename, content):
        self._files[filename] = content
        print(f"[Dropbox] Synced '{filename}' to your folder.")

    def download_file(self, filename):
        if filename in self._files:
            print(f"[Dropbox] Fetched '{filename}': {self._files[filename]}")
        else:
            print(f"[Dropbox] '{filename}' not found.")

    def delete_file(self, filename):
        if self._files.pop(filename, None) is not None:
            print(f"[Dropbox] Deleted '{filename}' (recoverable for 30 days).")
        else:
            print(f"[Dropbox] '{filename}' not found.")


class OneDrive(CloudStorage):
    def upload_file(self, filename, content):
        self._files[filename] = content
        print(f"[OneDrive] Saved '{filename}' to the cloud.")

    def download_file(self, filename):
        if filename in self._files:
            print(f"[OneDrive] Retrieved '{filename}': {self._files[filename]}")
        else:
            print(f"[OneDrive] '{filename}' not found.")

    def delete_file(self, filename):
        if self._files.pop(filename, None) is not None:
            print(f"[OneDrive] Removed '{filename}' to Recycle Bin.")
        else:
            print(f"[OneDrive] '{filename}' not found.")


for storage in (GoogleDrive(), Dropbox(), OneDrive()):
    storage.upload_file("notes.txt", "Abstraction demo")
    storage.download_file("notes.txt")
    storage.delete_file("notes.txt")
    storage.download_file("notes.txt")
    print()
