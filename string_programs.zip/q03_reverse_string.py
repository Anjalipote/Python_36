s = input("Enter a string: ")

reversed_s = ""
for ch in s:
    reversed_s = ch + reversed_s   # add each character to the front

print("Reversed string:", reversed_s)
