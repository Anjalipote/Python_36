from abc import ABC, abstractmethod


class Transport(ABC):
    @abstractmethod
    def calculate_fare(self, distance):
        pass


class Bus(Transport):
    def calculate_fare(self, distance):
        return max(10, distance * 1.5)  # Rs. 1.5/km, minimum Rs. 10


class Train(Transport):
    def calculate_fare(self, distance):
        return max(30, distance * 0.8)  # Rs. 0.8/km, minimum Rs. 30


class Taxi(Transport):
    def calculate_fare(self, distance):
        return 50 + distance * 14  # base Rs. 50 + Rs. 14/km


class Flight(Transport):
    def calculate_fare(self, distance):
        return 2000 + distance * 6  # base Rs. 2000 + Rs. 6/km


distance = float(input("Enter distance in km: "))

for t in (Bus(), Train(), Taxi(), Flight()):
    print(f"{t.__class__.__name__:<7} fare for {distance} km: Rs. {t.calculate_fare(distance):.2f}")
