"""
Question 28:
Count the frequency of each element in a tuple.
"""

t = (1, 2, 2, 3, 3, 3, 4)
freq = {}
for x in t:
    freq[x] = freq.get(x, 0) + 1
for element, count in freq.items():
    print(f"{element} -> {count}")
