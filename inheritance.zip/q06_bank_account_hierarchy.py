class BankAccount:
    def __init__(self, account_no, balance):
        self.account_no = account_no
        self.balance = balance

    def display(self):
        print(f"Account No : {self.account_no}")
        print(f"Balance    : Rs. {self.balance:.2f}")


class SavingsAccount(BankAccount):
    def __init__(self, account_no, balance, interest_rate):
        super().__init__(account_no, balance)
        self.interest_rate = interest_rate  # % per year

    def calculate_interest(self, years=1):
        return self.balance * self.interest_rate * years / 100

    def display(self):
        super().display()
        print(f"Interest   : {self.interest_rate}% per year")


class PremiumSavingsAccount(SavingsAccount):
    BONUS_RATE = 1.0  # extra 1% for premium customers

    def __init__(self, account_no, balance, interest_rate, benefits):
        super().__init__(account_no, balance, interest_rate)
        self.benefits = benefits

    def calculate_interest(self, years=1):
        total_rate = self.interest_rate + self.BONUS_RATE
        return self.balance * total_rate * years / 100

    def display(self):
        super().display()
        print(f"Benefits   : {', '.join(self.benefits)}")


s = SavingsAccount(1001, 100000, 4.0)
p = PremiumSavingsAccount(2001, 100000, 4.0,
                          ["Free cheque book", "Lounge access", "Zero charges"])

print("--- Savings Account ---")
s.display()
print(f"Interest for 2 years: Rs. {s.calculate_interest(2):.2f}")

print("\n--- Premium Savings Account ---")
p.display()
print(f"Interest for 2 years: Rs. {p.calculate_interest(2):.2f}")
