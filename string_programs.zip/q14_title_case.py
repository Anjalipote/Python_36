sentence = input("Enter a sentence: ")

result_words = []
for w in sentence.split():
    result_words.append(w[0].upper() + w[1:].lower())

print("Title case:", " ".join(result_words))
