"""
Question 7:
Accept 10 numbers from the user and store them in a list. Calculate the sum and the average.
"""

numbers = []
for i in range(10):
    numbers.append(float(input(f"Enter number {i + 1}: ")))
total = sum(numbers)
print("Numbers:", numbers)
print("Sum     :", total)
print("Average :", total / len(numbers))
