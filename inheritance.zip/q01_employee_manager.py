class Employee:
    def __init__(self, emp_id, name, salary):
        self.emp_id = emp_id
        self.name = name
        self.salary = salary  # monthly salary

    def display(self):
        print(f"Employee ID : {self.emp_id}")
        print(f"Name        : {self.name}")
        print(f"Salary      : Rs. {self.salary:.2f} per month")


class Manager(Employee):
    def __init__(self, emp_id, name, salary, department):
        super().__init__(emp_id, name, salary)
        self.department = department

    def annual_salary(self):
        return self.salary * 12

    def display(self):
        super().display()
        print(f"Department  : {self.department}")
        print(f"Annual Salary: Rs. {self.annual_salary():.2f}")


emp = Employee(101, "Rahul", 30000)
mgr = Manager(201, "Anjali", 80000, "Engineering")

print("--- Employee Details ---")
emp.display()
print("\n--- Manager Details ---")
mgr.display()
