class Employee:
    def __init__(self, emp_id, name, basic_salary):
        self.emp_id = emp_id
        self.name = name
        self.basic_salary = basic_salary

    def calculate_salary(self):
        return self.basic_salary

    def display(self):
        print(f"ID     : {self.emp_id}")
        print(f"Name   : {self.name}")
        print(f"Role   : {self.__class__.__name__}")
        print(f"Basic  : Rs. {self.basic_salary:.2f}")
        print(f"Salary : Rs. {self.calculate_salary():.2f}\n")


class Manager(Employee):
    def calculate_salary(self):
        # HRA 30% + Travel allowance 10% + Management allowance 15%
        return self.basic_salary * (1 + 0.30 + 0.10 + 0.15)


class Developer(Employee):
    def calculate_salary(self):
        # HRA 20% + Technology allowance 12%
        return self.basic_salary * (1 + 0.20 + 0.12)


class Tester(Employee):
    def calculate_salary(self):
        # HRA 20% + Testing allowance 8%
        return self.basic_salary * (1 + 0.20 + 0.08)


for emp in (Manager(1, "Anjali", 60000),
            Developer(2, "Rohan", 50000),
            Tester(3, "Meera", 40000)):
    emp.display()
