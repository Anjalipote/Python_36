# The "second most frequent" character(s) are those with the second-highest
# frequency value (spaces are ignored). Characters tied at that value are all shown.
s = input("Enter a string: ")

freq = {}
for ch in s:
    if ch != " ":
        freq[ch] = freq.get(ch, 0) + 1

counts = sorted(set(freq.values()), reverse=True)

if len(counts) < 2:
    print("There is no second most frequent character.")
else:
    second = counts[1]
    chars = [ch for ch, c in freq.items() if c == second]
    for ch in chars:
        print(f"Second most frequent character: '{ch}' (appears {second} times)")
