"""
Question 25:
Remove all duplicate elements while preserving the original order.
"""

numbers = [5, 3, 5, 2, 3, 8, 2, 9]
result = []
for n in numbers:
    if n not in result:
        result.append(n)
print("Original:", numbers)
print("Without duplicates:", result)
