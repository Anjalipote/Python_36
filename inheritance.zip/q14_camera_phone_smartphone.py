class Camera:
    def take_photo(self):
        print("Camera: Photograph captured.")

    def record_video(self):
        print("Camera: Video recording started.")


class Phone:
    def make_call(self, number):
        print(f"Phone: Calling {number} ...")

    def end_call(self):
        print("Phone: Call ended.")


class Smartphone(Camera, Phone):
    def __init__(self, brand, model):
        self.brand = brand
        self.model = model

    def display(self):
        print(f"Smartphone: {self.brand} {self.model}")


sp = Smartphone("Samsung", "Galaxy S24")
sp.display()
sp.take_photo()
sp.record_video()
sp.make_call("9876543210")
sp.end_call()
