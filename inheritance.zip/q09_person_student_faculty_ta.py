class Person:
    def __init__(self, name, age, **kwargs):
        super().__init__(**kwargs)
        self.name = name
        self.age = age

    def display(self):
        print(f"Name       : {self.name}")
        print(f"Age        : {self.age}")


class Student(Person):  # hierarchical: Person -> Student
    def __init__(self, roll_no, course, **kwargs):
        super().__init__(**kwargs)
        self.roll_no = roll_no
        self.course = course

    def display(self):
        super().display()
        print(f"Roll No    : {self.roll_no}")
        print(f"Course     : {self.course}")


class Faculty(Person):  # hierarchical: Person -> Faculty
    def __init__(self, emp_id, department, **kwargs):
        super().__init__(**kwargs)
        self.emp_id = emp_id
        self.department = department

    def display(self):
        super().display()
        print(f"Employee ID: {self.emp_id}")
        print(f"Department : {self.department}")


class TeachingAssistant(Student, Faculty):  # multiple inheritance
    def __init__(self, name, age, roll_no, course, emp_id, department, subject):
        super().__init__(name=name, age=age, roll_no=roll_no, course=course,
                         emp_id=emp_id, department=department)
        self.subject = subject

    def display(self):
        super().display()
        print(f"Assists in : {self.subject}")


ta = TeachingAssistant("Karan Mehta", 24, 7001, "M.Tech CSE",
                       501, "Computer Science", "Data Structures")
ta.display()

print("\nMethod Resolution Order:")
print(" -> ".join(c.__name__ for c in TeachingAssistant.__mro__))
