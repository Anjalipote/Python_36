"""
Question 4:
Create a dictionary containing student marks. Update the marks of a specified student.
"""

marks = {"Amit": 85, "Bhavna": 92, "Chetan": 78}
name = input("Enter student name: ").strip()
if name in marks:
    marks[name] = int(input("Enter new marks: "))
    print("Updated marks:", marks)
else:
    print("Student not found.")
