"""
Question 31:
Take a list of words, create a dictionary where the key is the word length and the value is a list of words having that length.
"""

words = ["apple", "fig", "kiwi", "plum", "banana", "pear", "cat", "mango"]
by_length = {}
for w in words:
    by_length.setdefault(len(w), []).append(w)
print(by_length)
