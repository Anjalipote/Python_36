main = input("Enter the main string: ")
sub = input("Enter the substring to search: ")

if sub in main:
    print(f"'{sub}' is present in the string (first found at index {main.find(sub)}).")
else:
    print(f"'{sub}' is not present in the string.")
