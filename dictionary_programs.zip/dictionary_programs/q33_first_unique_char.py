"""
Question 33:
Take a string, use a dictionary to find the first character that occurs only once.
"""

text = input("Enter a string: ")
freq = {}
for ch in text:
    freq[ch] = freq.get(ch, 0) + 1
for ch in text:
    if freq[ch] == 1:
        print("First non-repeating character:", ch)
        break
else:
    print("No non-repeating character found.")
