"""
Question 4:
Create a set of numbers and remove a specified number from the set.
"""

numbers = {10, 20, 30, 40, 50}
n = int(input("Enter the number to remove: "))
if n in numbers:
    numbers.remove(n)
    print("Updated set:", numbers)
else:
    print("Number not found in the set.")
