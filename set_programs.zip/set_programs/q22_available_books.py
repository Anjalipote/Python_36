"""
Question 22:
Create a set of available books and another set of requested books. Determine which requested books are available.
"""

available = {"Python Basics", "Data Structures", "Algorithms", "Networking"}
requested = {"Algorithms", "Operating Systems", "Python Basics"}
print("Requested books that are available    :", requested & available)
print("Requested books that are not available:", requested - available)
