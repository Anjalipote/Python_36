"""
Question 26:
Employee names and salaries: highest salary, lowest salary, average salary, employees earning more than Rs.50,000.
"""

salaries = {"Ravi": 45000, "Sneha": 52000, "Kiran": 38000, "Meera": 75000, "Arjun": 29000}
highest = max(salaries, key=salaries.get)
lowest = min(salaries, key=salaries.get)
print(f"Highest salary: {highest} ({salaries[highest]})")
print(f"Lowest salary : {lowest} ({salaries[lowest]})")
print("Average salary:", sum(salaries.values()) / len(salaries))
print("Employees earning more than 50,000:")
for name, sal in salaries.items():
    if sal > 50000:
        print(f"  {name}: {sal}")
