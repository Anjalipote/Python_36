from abc import ABC, abstractmethod
import hashlib


class Authentication(ABC):
    @abstractmethod
    def authenticate(self, credential):
        pass


class PasswordAuthentication(Authentication):
    def __init__(self, password):
        # Store only the hash, never the plain password
        self._hash = hashlib.sha256(password.encode()).hexdigest()

    def authenticate(self, credential):
        return hashlib.sha256(credential.encode()).hexdigest() == self._hash


class OTPAuthentication(Authentication):
    def __init__(self, generated_otp):
        self._otp = generated_otp

    def authenticate(self, credential):
        return credential == self._otp


class BiometricAuthentication(Authentication):
    def __init__(self, enrolled_fingerprint_id):
        self._fingerprint = enrolled_fingerprint_id

    def authenticate(self, credential):
        return credential == self._fingerprint


def login(method: Authentication, credential):
    """Works only through the abstract interface."""
    name = method.__class__.__name__
    if method.authenticate(credential):
        print(f"{name}: Access GRANTED")
    else:
        print(f"{name}: Access DENIED")


login(PasswordAuthentication("Secret@123"), "Secret@123")
login(PasswordAuthentication("Secret@123"), "wrong")
login(OTPAuthentication("482915"), "482915")
login(OTPAuthentication("482915"), "000000")
login(BiometricAuthentication("FP-7788"), "FP-7788")
login(BiometricAuthentication("FP-7788"), "FP-0001")
