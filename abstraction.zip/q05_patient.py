from abc import ABC, abstractmethod


class Patient(ABC):
    def __init__(self, patient_id, name):
        self.patient_id = patient_id
        self.name = name

    @abstractmethod
    def treatment(self):
        pass

    @abstractmethod
    def calculate_bill(self):
        pass

    def show(self):
        print(f"Patient   : {self.name} (ID {self.patient_id}) - {self.__class__.__name__}")
        print(f"Treatment : {self.treatment()}")
        print(f"Bill      : Rs. {self.calculate_bill():.2f}\n")


class InPatient(Patient):
    def __init__(self, patient_id, name, days, room_rate_per_day, treatment_cost):
        super().__init__(patient_id, name)
        self.days = days
        self.room_rate = room_rate_per_day
        self.treatment_cost = treatment_cost

    def treatment(self):
        return f"Admitted for {self.days} day(s) with ward care and monitoring"

    def calculate_bill(self):
        return self.days * self.room_rate + self.treatment_cost


class OutPatient(Patient):
    def __init__(self, patient_id, name, consultation_fee, medicine_cost):
        super().__init__(patient_id, name)
        self.consultation_fee = consultation_fee
        self.medicine_cost = medicine_cost

    def treatment(self):
        return "Consultation and prescription, no admission"

    def calculate_bill(self):
        return self.consultation_fee + self.medicine_cost


class EmergencyPatient(Patient):
    EMERGENCY_FEE = 5000

    def __init__(self, patient_id, name, treatment_cost):
        super().__init__(patient_id, name)
        self.treatment_cost = treatment_cost

    def treatment(self):
        return "Immediate life-saving care in the emergency ward"

    def calculate_bill(self):
        # Emergency fee + treatment + 20% priority surcharge on treatment
        return self.EMERGENCY_FEE + self.treatment_cost * 1.20


patients = [InPatient(1, "Ravi", 4, 3000, 15000),
            OutPatient(2, "Anita", 500, 650),
            EmergencyPatient(3, "Suresh", 40000)]

for p in patients:
    p.show()
