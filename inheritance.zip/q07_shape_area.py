import math


class Shape:
    def __init__(self, name):
        self.name = name

    def display_name(self):
        print(f"Shape: {self.name}")


class Circle(Shape):
    def __init__(self, radius):
        super().__init__("Circle")
        self.radius = radius

    def area(self):
        return math.pi * self.radius ** 2


class Rectangle(Shape):
    def __init__(self, length, breadth):
        super().__init__("Rectangle")
        self.length = length
        self.breadth = breadth

    def area(self):
        return self.length * self.breadth


class Triangle(Shape):
    def __init__(self, base, height):
        super().__init__("Triangle")
        self.base = base
        self.height = height

    def area(self):
        return 0.5 * self.base * self.height


for shape in (Circle(7), Rectangle(5, 3), Triangle(6, 4)):
    shape.display_name()
    print(f"Area: {shape.area():.2f}\n")
