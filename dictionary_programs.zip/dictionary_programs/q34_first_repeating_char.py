"""
Question 34:
Take a string, use a dictionary to find the first character that occurs more than once.
"""

text = input("Enter a string: ")
seen = {}
for ch in text:
    if ch in seen:
        print("First repeating character:", ch)
        break
    seen[ch] = True
else:
    print("No repeating character found.")
